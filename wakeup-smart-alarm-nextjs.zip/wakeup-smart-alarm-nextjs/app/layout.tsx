import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "WakeUp Smart Alarm",
  description: "No snooze. Solve 2 math problems and scan your washbasin to stop the alarm.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
