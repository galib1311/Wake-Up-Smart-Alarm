"use client";
import { useEffect, useRef, useState } from "react";
import { Alarm, Hist, Settings, DEFAULT_SETTINGS, Difficulty, DAYS, RINGTONES, VIB, fmt, makeProblem, basinScore, startSound } from "@/lib/core";
import { Splash, Onboarding, Stats, SettingsPage } from "@/components/Screens";

const load = <T,>(k: string, d: T): T => { try { return JSON.parse(localStorage.getItem(k) || ""); } catch { return d; } };
const blank = (s: Settings = DEFAULT_SETTINGS): Alarm => ({ id: crypto.randomUUID(), hour: 7, minute: 0, label: "Wake Up", enabled: true, days: [1, 2, 3, 4, 5], difficulty: s.difficulty, ringtone: s.ringtone, vibrate: s.vibrate });
const repeatText = (d: number[]) => !d.length ? "Once" : d.length === 7 ? "Every day" : d.map((x) => DAYS[x]).join(" • ");
function nextAt(a: Alarm) {
  const n = new Date();
  for (let i = 0; i < 8; i++) {
    const d = new Date(n); d.setDate(n.getDate() + i); d.setHours(a.hour, a.minute, 0, 0);
    if (d > n && (!a.days.length || a.days.includes(d.getDay()))) return d;
  }
  return null;
}
type Tab = "home" | "history" | "stats" | "settings";

export default function Home() {
  const [alarms, setAlarms] = useState<Alarm[]>([]);
  const [hist, setHist] = useState<Hist[]>([]);
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [ready, setReady] = useState(false);
  const [splash, setSplash] = useState(true);
  const [tab, setTab] = useState<Tab>("home");
  const [editing, setEditing] = useState<Alarm | null>(null);
  const [active, setActive] = useState<Alarm | null>(null);
  const [test, setTest] = useState(false);
  const fired = useRef("");

  useEffect(() => {
    setAlarms(load("wakeup.alarms", [])); setHist(load("wakeup.history", []));
    setSettings({ ...DEFAULT_SETTINGS, ...load("wakeup.settings", {}) }); setReady(true);
    const t = setTimeout(() => setSplash(false), 1800);
    return () => clearTimeout(t);
  }, []);
  useEffect(() => {
    if (!ready) return;
    localStorage.setItem("wakeup.alarms", JSON.stringify(alarms));
    localStorage.setItem("wakeup.history", JSON.stringify(hist));
    localStorage.setItem("wakeup.settings", JSON.stringify(settings));
  }, [alarms, hist, settings, ready]);
  useEffect(() => {
    const light = settings.theme === "LIGHT" || (settings.theme === "SYSTEM" && matchMedia("(prefers-color-scheme: light)").matches);
    document.documentElement.dataset.theme = light ? "light" : "dark";
  }, [settings.theme]);

  // check every second; alarm rings only while this tab is open
  useEffect(() => {
    const t = setInterval(() => {
      if (active) return;
      const n = new Date(), key = `${n.toDateString()}-${n.getHours()}:${n.getMinutes()}`;
      const a = alarms.find((a) => a.enabled && a.hour === n.getHours() && a.minute === n.getMinutes() && (!a.days.length || a.days.includes(n.getDay())));
      if (a && fired.current !== key + a.id) {
        fired.current = key + a.id; setTest(false); setActive(a);
        if (settings.notifications && "Notification" in window && Notification.permission === "granted") new Notification("⏰ " + a.label, { body: "Time to wake up!" });
      }
    }, 1000);
    return () => clearInterval(t);
  }, [alarms, active, settings.notifications]);

  const finish = (secs: number) => {
    if (!active) return;
    if (!test) {
      const n = new Date();
      setHist((h) => [{ id: crypto.randomUUID(), label: active.label, scheduled: fmt(active.hour, active.minute), completed: fmt(n.getHours(), n.getMinutes()), date: n.toDateString(), seconds: secs }, ...h].slice(0, 100));
      if (!active.days.length) setAlarms((as) => as.map((a) => (a.id === active.id ? { ...a, enabled: false } : a)));
    }
    setActive(null);
  };
  const save = (a: Alarm) => { setAlarms((as) => (as.some((x) => x.id === a.id) ? as.map((x) => (x.id === a.id ? a : x)) : [...as, a])); setEditing(null); };
  const runTest = () => { setTest(true); setTab("home"); setActive({ ...blank(settings), label: "Test Alarm" }); };
  const next = alarms.filter((a) => a.enabled).map((a) => ({ a, at: nextAt(a) })).filter((x) => x.at).sort((x, y) => +x.at! - +y.at!)[0];

  if (!ready || splash) return <Splash />;
  if (!settings.onboarded) return <Onboarding onDone={() => setSettings({ ...settings, onboarded: true })} />;

  return (
    <main>
      <div className="row"><img src="/logo.jpg" alt="" width={44} height={44} style={{ borderRadius: 12 }} /><h1>WakeUp Smart Alarm</h1></div>
      <p className="sub">No snooze. Solve 2 math problems, then scan your washbasin. Keep this tab open so the alarm can ring.</p>

      {tab === "home" && <>
        <div className="card">
          <div className="sub">NEXT ALARM</div>
          {next ? <><div className="time">{fmt(next.a.hour, next.a.minute)}</div><div className="sub">{next.a.label} · {next.at!.toLocaleString()}</div></> : <div>No alarm set</div>}
        </div>
        <div className="row">
          <button className="pri" onClick={() => setEditing(blank(settings))}>+ Create Smart Alarm</button>
          <button onClick={runTest}>Test</button>
        </div>
        <h2>ALARMS</h2>
        {!alarms.length && <p className="sub">No alarms yet. Create your first one.</p>}
        {alarms.map((a) => (
          <div className="card row" key={a.id}>
            <div className="grow" onClick={() => setEditing(a)} style={{ cursor: "pointer" }}>
              <div className="time">{fmt(a.hour, a.minute)}</div>
              <div className="sub">{a.label} · {repeatText(a.days)} · {a.difficulty} Math</div>
            </div>
            <button className={a.enabled ? "on" : ""} onClick={() => setAlarms(alarms.map((x) => (x.id === a.id ? { ...x, enabled: !x.enabled } : x)))}>{a.enabled ? "ON" : "OFF"}</button>
            <button onClick={() => setAlarms(alarms.filter((x) => x.id !== a.id))}>🗑</button>
          </div>
        ))}
      </>}

      {tab === "history" && <>
        <h2>HISTORY</h2>
        {!hist.length && <p className="sub">Completed alarms will show up here.</p>}
        {hist.map((h) => (
          <div className="card" key={h.id}><b>{h.label}</b> <span className="sub">· {h.date}</span><div className="sub">{h.scheduled} → {h.completed} · {Math.floor(h.seconds / 60)}m {h.seconds % 60}s</div></div>
        ))}
        {!!hist.length && <button onClick={() => setHist([])}>Clear history</button>}
      </>}

      {tab === "stats" && <Stats hist={hist} />}
      {tab === "settings" && <SettingsPage s={settings} set={setSettings} onTest={runTest} />}

      <nav className="nav">
        {([["home", "⏰ Alarms"], ["history", "🕘 History"], ["stats", "📊 Stats"], ["settings", "⚙️ Settings"]] as [Tab, string][]).map(([t, l]) => (
          <button key={t} className={tab === t ? "on" : ""} onClick={() => setTab(t)}>{l}</button>
        ))}
      </nav>

      {editing && <Editor alarm={editing} onSave={save} onClose={() => setEditing(null)} />}
      {active && <Active alarm={active} test={test} volume={settings.volume} pattern={settings.pattern} onDone={finish} />}
    </main>
  );
}

function Editor({ alarm, onSave, onClose }: { alarm: Alarm; onSave: (a: Alarm) => void; onClose: () => void }) {
  const [a, setA] = useState(alarm);
  const set = (p: Partial<Alarm>) => setA({ ...a, ...p });
  const toggle = (d: number) => set({ days: a.days.includes(d) ? a.days.filter((x) => x !== d) : [...a.days, d].sort() });
  const time = `${String(a.hour).padStart(2, "0")}:${String(a.minute).padStart(2, "0")}`;
  return (
    <div className="overlay"><div className="in" style={{ textAlign: "left" }}>
      <h1>{alarm.label ? "Edit Alarm" : "New Alarm"}</h1>
      <h2>TIME</h2>
      <input type="time" value={time} onChange={(e) => { const [h, m] = e.target.value.split(":").map(Number); if (!isNaN(h)) set({ hour: h, minute: m }); }} />
      <h2>LABEL</h2>
      <input value={a.label} onChange={(e) => set({ label: e.target.value })} />
      <h2>REPEAT</h2>
      <div className="chips">
        <button onClick={() => set({ days: [] })}>Once</button>
        <button onClick={() => set({ days: [0, 1, 2, 3, 4, 5, 6] })}>Every day</button>
        <button onClick={() => set({ days: [1, 2, 3, 4, 5] })}>Weekdays</button>
        <button onClick={() => set({ days: [0, 6] })}>Weekends</button>
      </div>
      <div className="chips">{DAYS.map((d, i) => <button key={d} className={a.days.includes(i) ? "on" : ""} onClick={() => toggle(i)}>{d}</button>)}</div>
      <h2>MATH DIFFICULTY</h2>
      <div className="chips">{(["EASY", "MEDIUM", "HARD"] as Difficulty[]).map((d) => <button key={d} className={a.difficulty === d ? "on" : ""} onClick={() => set({ difficulty: d })}>{d}</button>)}</div>
      <h2>RINGTONE</h2>
      <select value={a.ringtone} onChange={(e) => set({ ringtone: e.target.value })}>{RINGTONES.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</select>
      <label className="row" style={{ margin: "14px 0" }}><input type="checkbox" style={{ width: 20 }} checked={a.vibrate} onChange={(e) => set({ vibrate: e.target.checked })} /> Vibrate</label>
      <button className="pri" onClick={() => onSave(a)}>Save Alarm</button>
      <button className="big" style={{ marginTop: 10 }} onClick={onClose}>Cancel</button>
    </div></div>
  );
}

type Stage = "ring" | "m1" | "m2" | "cam" | "done";
function Active({ alarm, test, volume, pattern, onDone }: { alarm: Alarm; test: boolean; volume: number; pattern: string; onDone: (secs: number) => void }) {
  const [stage, setStage] = useState<Stage>("ring");
  const [p1] = useState(() => makeProblem(alarm.difficulty));
  const [p2] = useState(() => makeProblem(alarm.difficulty));
  const [ans, setAns] = useState("");
  const [err, setErr] = useState(false);
  const t0 = useRef(Date.now());
  const finished = stage === "done";

  useEffect(() => {
    if (finished) return;
    const stop = startSound((RINGTONES.find((r) => r.id === alarm.ringtone) || RINGTONES[0]).notes, volume);
    const vp = VIB[pattern] || VIB.STRONG;
    const v = alarm.vibrate && navigator.vibrate ? setInterval(() => navigator.vibrate(vp), vp.reduce((a, b) => a + b, 0) + 300) : undefined;
    return () => { stop(); if (v) clearInterval(v); if (navigator.vibrate) navigator.vibrate(0); };
  }, [alarm, finished, volume, pattern]);

  const submit = () => {
    const p = stage === "m1" ? p1 : p2;
    if (Number(ans) === p.answer) { setErr(false); setAns(""); setStage(stage === "m1" ? "m2" : "cam"); } else setErr(true);
  };

  return (
    <div className="overlay"><div className="in">
      <div className="sub">NO SNOOZE • CHALLENGE MANDATORY</div>
      <h1>{fmt(alarm.hour, alarm.minute)} · {alarm.label}</h1>
      {stage === "ring" && <>
        <div className="ring">⏰</div>
        <p>Wake up! Solve 2 calculations & scan the basin to stop.</p>
        <button className="pri" onClick={() => setStage("m1")}>Solve Challenge 1/2</button>
      </>}
      {(stage === "m1" || stage === "m2") && <>
        <h2>MATH CHALLENGE {stage === "m1" ? 1 : 2} OF 2</h2>
        <div className="expr">{(stage === "m1" ? p1 : p2).expr}</div>
        <input className="ans" type="number" inputMode="numeric" autoFocus value={ans} onChange={(e) => setAns(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} placeholder="Answer" />
        {err && <p className="err">Wrong answer, try again.</p>}
        <button className="pri" style={{ marginTop: 14 }} onClick={submit}>Submit Answer</button>
      </>}
      {stage === "cam" && <Cam onOk={() => setStage("done")} />}
      {stage === "done" && <>
        <div className="ring">✅</div>
        <h1>Great! You&apos;re awake.</h1>
        <p className="sub">You solved 2 math problems and verified your washbasin.</p>
        <button className="pri" onClick={() => onDone(Math.round((Date.now() - t0.current) / 1000))}>Finish & Return Home</button>
      </>}
      {test && stage !== "done" && <button style={{ marginTop: 24 }} onClick={() => onDone(0)}>Exit test</button>}
    </div></div>
  );
}

function Cam({ onOk }: { onOk: () => void }) {
  const v = useRef<HTMLVideoElement>(null);
  const [msg, setMsg] = useState("Starting camera...");
  const [pct, setPct] = useState(0);
  const [denied, setDenied] = useState(false);
  useEffect(() => {
    let stream: MediaStream | undefined, timer: ReturnType<typeof setInterval> | undefined, hits = 0;
    const c = document.createElement("canvas"); c.width = 320; c.height = 240;
    const x = c.getContext("2d", { willReadFrequently: true })!;
    navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } }).then((s) => {
      stream = s;
      if (v.current) { v.current.srcObject = s; v.current.play(); }
      setMsg("Align washbasin clearly inside the frame");
      timer = setInterval(() => {
        if (!v.current || !v.current.videoWidth) return;
        x.drawImage(v.current, 0, 0, 320, 240);
        hits = basinScore(x.getImageData(0, 0, 320, 240)) >= 0.48 ? hits + 1 : Math.max(0, hits - 1);
        setPct(Math.min(100, (hits / 6) * 100));
        if (hits >= 6) { clearInterval(timer); onOk(); }
      }, 200);
    }).catch(() => { setDenied(true); setMsg("Camera permission required to verify you left your bed."); });
    return () => { if (timer) clearInterval(timer); stream?.getTracks().forEach((t) => t.stop()); };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  return <>
    <h2>STAGE 3/3: BASIN CAMERA DETECTION</h2>
    <p>Walk to your washbasin and show it clearly inside the frame.</p>
    <video ref={v} playsInline muted />
    <div className="bar"><i style={{ width: `${pct}%` }} /></div>
    <p className="sub">{msg}</p>
    {denied && <button onClick={onOk}>Manual Basin Verification</button>}
  </>;
}
