export type Difficulty = "EASY" | "MEDIUM" | "HARD";
export type Alarm = { id: string; hour: number; minute: number; label: string; enabled: boolean; days: number[]; difficulty: Difficulty; ringtone: string; vibrate: boolean };
export type Hist = { id: string; label: string; scheduled: string; completed: string; date: string; seconds: number };
export const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
type Note = [number, number, number]; // freq Hz, duration ms, gain
const seq = (fs: number[], ms: number, g: number): Note[] => fs.map((f) => [f, ms, g]);
export const RINGTONES: { id: string; name: string; notes: Note[] }[] = [
  { id: "morning_birds", name: "Morning Birds", notes: seq([1760, 2093, 2349, 2637, 2093, 1760], 90, 0.7) },
  { id: "classic_alarm", name: "Classic Alarm", notes: seq([880, 988, 880, 988], 120, 0.9) },
  { id: "gentle_wake", name: "Gentle Wake", notes: seq([523.25, 659.25, 783.99, 1046.5, 783.99, 659.25], 220, 0.6) },
  { id: "digital_beep", name: "Digital Beep", notes: seq([1200, 1200, 1400], 80, 0.8) },
  { id: "sunrise", name: "Sunrise", notes: [...seq([440, 554.37, 659.25, 880, 1108.73, 1318.51], 140, 0.75), [1760, 350, 0.8]] },
  { id: "energetic", name: "Energetic", notes: seq([659.25, 659.25, 783.99, 987.77, 1318.51, 987.77, 783.99], 100, 0.85) },
  { id: "loud_bell", name: "Loud Bell", notes: seq([740, 880, 740, 880], 250, 0.95) },
  { id: "nature_wake", name: "Nature Wake", notes: seq([880, 1174.66, 1318.51, 1567.98, 1760], 180, 0.65) },
  { id: "piano_morning", name: "Piano Morning", notes: seq([523.25, 659.25, 783.99, 987.77, 1046.5, 1318.51], 160, 0.7) },
  { id: "mission_alarm", name: "Mission Alarm", notes: seq([1000, 1500, 1000, 1500], 100, 0.9) },
];
export const VIB: Record<string, number[]> = { STANDARD: [500, 400, 500, 400], STRONG: [800, 200, 800, 200, 1000, 200], PULSE: [200, 100, 200, 100, 200, 400] };
export type Settings = { onboarded: boolean; theme: "SYSTEM" | "LIGHT" | "DARK"; ringtone: string; difficulty: Difficulty; volume: number; vibrate: boolean; pattern: string; notifications: boolean };
export const DEFAULT_SETTINGS: Settings = { onboarded: false, theme: "SYSTEM", ringtone: "morning_birds", difficulty: "MEDIUM", volume: 1, vibrate: true, pattern: "STRONG", notifications: true };
export const fmt = (h: number, m: number) =>
  `${String(h % 12 || 12).padStart(2, "0")}:${String(m).padStart(2, "0")} ${h >= 12 ? "PM" : "AM"}`;

// ---- Math engine (all operands 1..10, whole-number answers) ----
const DIV: [number, number][] = [[4, 2], [6, 2], [6, 3], [8, 2], [8, 4], [9, 3], [10, 2], [10, 5]];
const r = (a: number, b: number) => Math.floor(Math.random() * (b - a + 1)) + a;
const pick = <T,>(x: T[]) => x[r(0, x.length - 1)];
export function makeProblem(d: Difficulty): { expr: string; answer: number } {
  for (let i = 0; i < 100; i++) {
    const [n, v] = pick(DIV), q = n / v, a = r(1, 10), b = r(1, 10), c = r(2, 10), e = r(1, 10), f = r(2, 10);
    const set: Record<Difficulty, [string, number][]> = {
      EASY: [
        [`(${a} + ${b}) × ${c} - ${e}`, (a + b) * c - e],
        [`${a} + (${c} × ${f}) - ${e}`, a + c * f - e],
        [`(${n} ÷ ${v}) + (${c} × ${f}) - ${e}`, q + c * f - e],
      ],
      MEDIUM: [
        [`(${a} + ${b}) × ${c} - (${n} ÷ ${v}) + ${f}`, (a + b) * c - q + f],
        [`${a} + (${c} × ${f}) - (${n} ÷ ${v}) × ${e}`, a + c * f - q * e],
      ],
      HARD: [
        [`((${a} + ${b}) × ${c} - ${e}) + (${f} × ${c}) - (${n} ÷ ${v}) + ${a}`, (a + b) * c - e + f * c - q + a],
        [`${a} + ((${b} + ${e}) × ${c}) - (${f} × ${c}) + (${n} ÷ ${v}) × ${f}`, a + (b + e) * c - f * c + q * f],
      ],
    };
    const [expr, answer] = pick(set[d]);
    if (answer >= 1 && answer <= 999) return { expr, answer };
  }
  return { expr: "(8 + 6) × 3 - 10 ÷ 2", answer: 37 };
}

// ---- Basin detection (same scoring idea as BasinDetector.kt, on canvas pixels) ----
export function basinScore(img: ImageData): number {
  const { width: w, height: h, data } = img;
  const cx = w >> 1, cy = h >> 1, R = Math.min(w, h) / 3, step = 8;
  let n = 0, tot = 0, mn = 255, mx = 0, cs = 0, cc = 0, rs = 0, rc = 0, edges = 0;
  const pts: number[] = [];
  for (let y = Math.floor(cy - R); y < cy + R; y += step) {
    if (y < 0 || y >= h) continue;
    for (let x = Math.floor(cx - R); x < cx + R; x += step) {
      if (x < 0 || x >= w) continue;
      const i = (y * w + x) * 4, l = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
      pts.push(l); tot += l; n++; mn = Math.min(mn, l); mx = Math.max(mx, l);
      const d2 = (x - cx) ** 2 + (y - cy) ** 2, r2 = R * R;
      if (d2 < r2 * 0.25) { cs += l; cc++; } else if (d2 >= r2 * 0.5 && d2 <= r2) { rs += l; rc++; }
    }
  }
  if (n < 20) return 0;
  for (let i = 0; i < pts.length - 1; i++) if (Math.abs(pts[i] - pts[i + 1]) > 28) edges++;
  const avg = tot / n, range = mx - mn, er = edges / n;
  let s = 0;
  if (range > 60) s += 0.25;
  if (range > 110) s += 0.15;
  if (avg >= 45 && avg <= 230) s += 0.25;
  if (er >= 0.12 && er <= 0.65) s += 0.25;
  if (cc && rc && Math.abs(rs / rc - cs / cc) > 12) s += 0.15;
  return Math.min(1, s);
}

// ---- Alarm sound (Web Audio, loops the ringtone's note sequence) ----
export function startSound(notes: Note[], volume = 1) {
  const ctx = new AudioContext();
  ctx.resume();
  let alive = true, i = 0, t: ReturnType<typeof setTimeout> | undefined;
  const play = () => {
    if (!alive) return;
    const [f, ms, g] = notes[i % notes.length];
    i++;
    const o = ctx.createOscillator(), gain = ctx.createGain();
    o.type = "square"; o.frequency.value = f; gain.gain.value = 0.3 * g * volume;
    o.connect(gain); gain.connect(ctx.destination); o.start(); o.stop(ctx.currentTime + ms / 1000);
    t = setTimeout(play, ms + (i % notes.length === 0 ? 300 : 30));
  };
  play();
  return () => { alive = false; clearTimeout(t); ctx.close(); };
}
