"use client";
import { useState } from "react";
import { Hist, Settings, Difficulty, RINGTONES } from "@/lib/core";

export function Splash() {
  return (
    <div className="splash">
      <img src="/logo.jpg" alt="" width={96} height={96} style={{ borderRadius: 24 }} />
      <h1>WakeUp Smart Alarm</h1>
      <p className="sub">Wake Up. Get Up. Start Your Day.</p>
      <b style={{ color: "var(--orange)" }}>No Snooze. No Excuses.</b>
    </div>
  );
}

const PAGES = [
  { img: "/onb1.jpg", title: "Wake Up Smarter", d: "Create powerful alarms that actually get you out of bed." },
  { img: "/onb2.jpg", title: "Think Before You Snooze", d: "Solve challenging math calculations before you can move to the next step." },
  { img: "/onb3.jpg", title: "Get Up & Show the Basin", d: "Complete the final camera challenge to prove you're awake." },
];
export function Onboarding({ onDone }: { onDone: () => void }) {
  const [i, setI] = useState(0);
  const [cam, setCam] = useState(false);
  const [notif, setNotif] = useState(false);
  const askCam = () => navigator.mediaDevices.getUserMedia({ video: true }).then((s) => { s.getTracks().forEach((t) => t.stop()); setCam(true); }).catch(() => {});
  const askNotif = () => Notification.requestPermission().then((r) => setNotif(r === "granted"));
  return (
    <main style={{ textAlign: "center" }}>
      {i < 3 ? <>
        <img src={PAGES[i].img} alt="" style={{ width: "100%", borderRadius: 20, marginTop: 20 }} />
        <h1 style={{ marginTop: 20 }}>{PAGES[i].title}</h1>
        <p className="sub">{PAGES[i].d}</p>
        <div className="row" style={{ marginTop: 24 }}>
          <button onClick={() => setI(3)}>Skip</button>
          <div className="grow" />
          <button className="pri" style={{ width: "auto" }} onClick={() => setI(i + 1)}>{i === 2 ? "Get Started" : "Next"}</button>
        </div>
      </> : <>
        <h1 style={{ marginTop: 40 }}>Essential Permissions</h1>
        <p className="sub">To guarantee you wake up on time and complete challenges, please grant the following permissions:</p>
        <div className="card"><b>Camera Permission</b><div className="sub">Used exclusively for on-device basin verification.</div>
          <button style={{ marginTop: 8 }} onClick={askCam}>{cam ? "✓ Granted" : "Allow Camera"}</button></div>
        <div className="card"><b>Notifications</b><div className="sub">Alerts you reliably when scheduled alarms ring.</div>
          <button style={{ marginTop: 8 }} onClick={askNotif}>{notif ? "✓ Granted" : "Allow Notifications"}</button></div>
        <button className="pri" onClick={onDone}>Continue to App</button>
      </>}
    </main>
  );
}

export function Stats({ hist }: { hist: Hist[] }) {
  const total = hist.length, streak = Math.min(total, 30);
  const avg = total ? Math.round(hist.reduce((a, h) => a + h.seconds, 0) / total) : 0;
  const days = Array.from({ length: 7 }, (_, k) => { const d = new Date(); d.setDate(d.getDate() - (6 - k)); return { l: d.toLocaleDateString("en", { weekday: "short" }), n: hist.filter((h) => h.date === d.toDateString()).length }; });
  const mx = Math.max(1, ...days.map((d) => d.n));
  const badges = [["Zero Snooze Pioneer", total >= 1, "Complete 1 alarm"], ["Math Master", total * 2 >= 10, "Solve 10 calculations"], ["Basin Champion", total >= 5, "5 basin scans"]] as const;
  return <>
    <h2>WAKE-UP STATISTICS</h2>
    <div className="card"><div className="sub">WAKE-UP STREAK</div><div className="time">{streak} Days</div>
      <div className="sub">{streak ? "Great consistency! Keep up the momentum." : "Complete your next alarm to start a streak."}</div></div>
    <div className="grid2">
      <div className="card"><div className="big-n">{total}</div><div className="sub">Completed</div></div>
      <div className="card"><div className="big-n">{total * 2}</div><div className="sub">Math Solved</div></div>
      <div className="card"><div className="big-n">{total}</div><div className="sub">Basin Scans</div></div>
      <div className="card"><div className="big-n">{avg ? `${Math.floor(avg / 60)}m ${avg % 60}s` : "--"}</div><div className="sub">Avg. Speed</div></div>
    </div>
    <h2>WEEKLY ACTIVITY PATTERN</h2>
    <div className="card wk">{days.map((d, k) => <div key={k}><i style={{ height: `${(d.n / mx) * 60 + 4}px` }} />{d.l}</div>)}</div>
    <h2>DISCIPLINE BADGES</h2>
    {badges.map(([t, got, d]) => <div key={t} className={`card badge ${got ? "got" : ""}`}><b>{got ? "🏅" : "🔒"} {t}</b><div className="sub">{d}</div></div>)}
  </>;
}

export function SettingsPage({ s, set, onTest }: { s: Settings; set: (s: Settings) => void; onTest: () => void }) {
  const u = (p: Partial<Settings>) => set({ ...s, ...p });
  const chips = (opts: string[], cur: string, on: (v: string) => void) => <div className="chips">{opts.map((o) => <button key={o} className={cur === o ? "on" : ""} onClick={() => on(o)}>{o}</button>)}</div>;
  return <>
    <h2>APPEARANCE & THEME</h2>
    {chips(["SYSTEM", "LIGHT", "DARK"], s.theme, (v) => u({ theme: v as Settings["theme"] }))}
    <h2>DEFAULT AUDIO & VOLUME</h2>
    <div className="sub">Alarm Volume: {Math.round(s.volume * 100)}%</div>
    <input type="range" min={0.1} max={1} step={0.1} value={s.volume} onChange={(e) => u({ volume: Number(e.target.value) })} />
    <div className="sub" style={{ marginTop: 10 }}>Default Sound</div>
    <select value={s.ringtone} onChange={(e) => u({ ringtone: e.target.value })}>{RINGTONES.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</select>
    <h2>DEFAULT MATH DIFFICULTY</h2>
    {chips(["EASY", "MEDIUM", "HARD"], s.difficulty, (v) => u({ difficulty: v as Difficulty }))}
    <h2>VIBRATION FEEDBACK</h2>
    <label className="row"><input type="checkbox" style={{ width: 20 }} checked={s.vibrate} onChange={(e) => u({ vibrate: e.target.checked })} /> Enabled</label>
    {chips(["STANDARD", "STRONG", "PULSE"], s.pattern, (v) => u({ pattern: v }))}
    <h2>ALARM NOTIFICATIONS</h2>
    <label className="row"><input type="checkbox" style={{ width: 20 }} checked={s.notifications} onChange={(e) => { u({ notifications: e.target.checked }); if (e.target.checked && "Notification" in window) Notification.requestPermission(); }} /> Enabled</label>
    <button className="big" style={{ marginTop: 20 }} onClick={onTest}>Test Alarm & Basin Challenge Flow</button>
    <h2>ABOUT WAKEUP SMART ALARM</h2>
    <div className="card"><b>WakeUp Smart Alarm v1.0.0</b><div className="sub">“Wake Up. Get Up. Start Your Day.”</div>
      <p className="sub">Guarantees you physically get out of bed to solve math and reach the washbasin before the alarm stops.</p>
      <div className="sub">Privacy: 100% on-device camera & data processing.</div></div>
  </>;
}
